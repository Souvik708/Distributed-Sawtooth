## Maintainers

### Active Maintainers
| Name | GitHub | RocketChat |
| --- | --- | --- |
| Andi Gunderson | agunde406 | agunde |
| Anne Chenette | chenette | achenette |
| Cian Montgomery | cianx | cianx |
| Dan Middleton | dcmiddle | Dan |
| Darian Plumb | dplumb94 | dplumb |
| James Mitchell | jsmitchell | jsmitchell |
| Logan Seeley | ltseeley | ltseeley |
| Peter Schwarz | peterschwarz | pschwarz |
| Richard Berg | rberg2 | rberg2 |
| Ryan Beck-Buysse | rbuysse | rbuysse |
| Shawn Amundson | vaporos | amundson |

### Retired Maintainers
| Name | GitHub | RocketChat |
| --- | --- | --- |
| Adam Ludvik | aludvik | adamludvik |
| Boyd Johnson | boydjohnson | boydjohnson |
| Jamie Jason | jjason | jjason |
| Nick Drozd | nick-drozd | drozd |
| Zac Delventhal | delventhalz | zac |
