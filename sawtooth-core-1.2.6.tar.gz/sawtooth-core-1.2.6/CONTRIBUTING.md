# Contributing to Hyperledger Sawtooth

Hyperledger Sawtooth is Apache 2.0 licensed and accepts contributions via
[GitHub](https://github.com/hyperledger/sawtooth-core) pull requests.

Please see
[Contributing](https://sawtooth.hyperledger.org/docs/core/releases/latest/community/contributing.html)
in the Sawtooth documentation for information on how to contribute and the guidelines for contributions.

