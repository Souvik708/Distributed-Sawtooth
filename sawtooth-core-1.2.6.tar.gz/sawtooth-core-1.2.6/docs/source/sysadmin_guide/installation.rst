*******************************
Installing Hyperledger Sawtooth
*******************************

.. note::

    These instructions have been tested on Ubuntu 18.04 (Bionic) only.

This procedure describes how to install Hyperledger Sawtooth on a Ubuntu system
for proof-of-concept or production use in a Sawtooth network.

.. include:: ../_includes/install-sawtooth.inc


.. Licensed under Creative Commons Attribution 4.0 International License
.. https://creativecommons.org/licenses/by/4.0/
